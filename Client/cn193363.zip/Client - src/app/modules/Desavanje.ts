export interface Desavanje {
    id: number
    privatno: boolean
    naziv: string
    pocetak: Date
    kraj: Date
    opis: string
    aktivno: boolean
    kreator: string
}