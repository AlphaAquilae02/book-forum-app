export interface Komentar {
    id:string
    korisnikId:string
    knjigaId:string
    komentar:string
    ocena:number
}